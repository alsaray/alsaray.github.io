do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "banhammer",
    "groupmanager",
    "msg-checks",
    "plugins",
    "replay",
    "tools"
  },
  info_text = "💢| Welcome My Dear\n💢| verbot V2 \n💢| For Information  @verxbot \n💢| Dev @blcon\n\n",
  moderation = {
    data = "./data/moderation.json"
  },
  sudo_users = {
    352568466,
    51333226,
    60809019,
    411747122,
    418448068,
    382257193,
    315405644
  }
}
return _
end