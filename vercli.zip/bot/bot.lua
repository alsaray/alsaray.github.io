
if namecut(msg.from.first_name)  then
isname = '💢¦ اسمك : '..namecut(msg.from.first_name)
else
isname = ''
end

if status.result.total_count ~= 0 then
	sendPhotoById(msg.to.id, status.result.photos[1][1].file_id, msg.id, isname..'\n💢¦ معرفك : '..userxn..'\n💢¦ ايديك : '..msg.from.id..'\n💢¦ رتبتك : '..rank..'\n💬¦ رسائلك : ['..msgs..'] رسالة 💯\n')
	else
return '💢¦لا توجد صورة في بروفايلك !!! \n💢¦ اسمك : '..namecut(msg.from.first_name)..'\n💢¦ معرفك : '..userxn..'\n💢¦ ايديك : '..msg.from.id..'\n💢¦ رتبتك : '..rank..'\n💬¦ رسائلك : ['..msgs..'] رسالة 💯\n'
end